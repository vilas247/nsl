<link rel="stylesheet" href="./css/custom.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
	var base_url = "http://workspacedev.247commerce.co.uk/247pod2/";
	var pId = "1289";
	var sku = "2018AB91558";
	var pod_img_url = "http://workspacedev.247commerce.co.uk/247pod2/pub/media/catalog/product/m/_/m_2018ab91558.jpg";
	var pod_title = "Blue/Red/Black - Tree Image";
</script>
<script src="./js/custom.js"></script>

<div id="fadeMaster">
	<img src="./images/loader.gif" id="img_loader" style="z-index:1;position: absolute;" />
	<div id="podProductImageBox"></div>
	<div id="podProductFormBox"></div>
</div>
<script type="text/javascript">
function fetch_pod_skus(imageid, internalsku, qnty, price) {
	alert("entered");
}
</script>

